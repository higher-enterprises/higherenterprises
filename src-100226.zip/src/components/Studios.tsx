"use client";

import { useState } from "react";
import Image from "next/image";
import StudioLogo from "@/components/StudioLogo";
import StudioModal from "@/components/StudioModal";
import { studios } from "@/data/studios";

const studioImages: Record<string, string> = {
  "SIBZ": "/assets/companies/examples/sibz.png",
  "BLUE EAGLE": "/assets/companies/examples/partsy.png",
  "CLEAVE": "/assets/companies/examples/caleb-ai.png",
  "BELOVED": "/assets/companies/examples/thankworthy.png",
  "D2X": "/assets/companies/examples/tentmaker.png",
  "TENTMAKER": "/assets/companies/examples/tentmaker.png",
  "ACTS": "/assets/companies/examples/acts.png",
  "THANKWORTHY": "/assets/companies/examples/thankworthy.png",
  "RAZED": "/assets/companies/examples/greenwood-labs.png",
  "FLYY": "/assets/companies/examples/world-rebuilders.png",
  "BLACK EAGLE": "/assets/companies/examples/agree-legal.png",
  "ALPHA7": "/assets/companies/examples/alpha7.png",
};

type Studio = (typeof studios)[number];

export default function Studios({ embedded = false }: { embedded?: boolean }) {
  const [selectedStudio, setSelectedStudio] = useState<Studio | null>(null);

  const openStudio = (studio: Studio) => setSelectedStudio(studio);
  const closeStudio = () => setSelectedStudio(null);

  const handleKeyDown = (
    event: React.KeyboardEvent<HTMLElement>,
    studio: Studio
  ) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      openStudio(studio);
    }
  };

  return (
    <>
      <section
        id="studios"
        className={embedded ? "studios studiosEmbedded" : "studios section"}
      >
        <div className="studioGrid studioRevealGrid">
          {studios.map((studio) => (
            <article
              className="studio studioReveal studioLaunchCard"
              key={studio.slug}
              role="button"
              tabIndex={0}
              aria-label={`Open ${studio.name} studio`}
              onClick={() => openStudio(studio)}
              onKeyDown={(event) => handleKeyDown(event, studio)}
            >
              <Image
                className="studioPhoto"
                src={studioImages[studio.name]}
                alt=""
                fill
                sizes="(max-width: 1100px) 22vw, 15vw"
              />

              <div className="studioPhotoShade" />

              <div className="studioFace">
                <div className="studioMark">
                  <StudioLogo studio={studio.name} />
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <StudioModal studio={selectedStudio} onClose={closeStudio} />
    </>
  );
}
