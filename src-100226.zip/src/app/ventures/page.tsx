import CompaniesRail from "@/components/CompaniesRail";

export default function CompaniesPage() {
  return (
    <section className="screenPage companiesPage">
      <div className="venturesHero">
        <div className="venturesTitle" aria-hidden="true">
          what we're building
        </div>

        <div className="venturesSubtitle">
          VENTURES IN MOTION
        </div>
      </div>

      <div className="companiesContent">
        <CompaniesRail />
      </div>
    </section>
  );
}