import Screen from "@/components/Screen";
import Studios from "@/components/Studios";

export default function StudiosPage() {
  return (
    <Screen
      eyebrow="OUR VENTURE STUDIOS"
      title={"where we're\nbuilding"}
    >
      <Studios embedded />
    </Screen>
  );
}