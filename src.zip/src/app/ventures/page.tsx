import CompaniesRail from "@/components/CompaniesRail";

export default function CompaniesPage(){
  return (
    <section className="screenPage companiesPage">
      <header className="companiesHeading">
        <h1>Ventures</h1>
      </header>
      <div className="companiesContent"><CompaniesRail/></div>
    </section>
  );
}
