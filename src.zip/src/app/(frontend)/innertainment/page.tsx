import InnertainmentExperience from "@/components/innertainment/InnertainmentExperience";
export default function Page(){return <InnertainmentExperience/>;}
