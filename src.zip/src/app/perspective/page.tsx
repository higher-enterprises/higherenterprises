import Screen from "@/components/Screen";
import Perspectives from "@/components/Perspectives";

export default function PerspectivesPage(){
  return (
    <Screen title="Wisdoms" intro="Seven wisdoms shape how we build, strengthen and release ventures.">
      <Perspectives embedded/>
    </Screen>
  );
}
