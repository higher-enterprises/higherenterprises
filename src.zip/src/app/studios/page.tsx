import Screen from "@/components/Screen";
import Studios from "@/components/Studios";

export default function StudiosPage(){
 return <Screen eyebrow="OUR NETWORK" title="Venture Studios" intro={
  <div className="studioIntroCopy">
   <p>HIGHER.VENTURES is a network of twelve focused venture studios built around people, institutions, communities, and industries where new companies can create meaningful value. Each studio understands its own field while sharing the larger systems, technology, relationships, and operating discipline of the HIGHER.VENTURES network.</p>
  </div>
 }><Studios embedded/></Screen>;
}
