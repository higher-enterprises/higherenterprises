"use client";
import StudioLogo from "@/components/StudioLogo";
import Image from "next/image";
import { studios } from "@/data/studios";

const studioImages:Record<string,string>={
  "SIBZ":"/assets/companies/examples/sibz.jpg",
  "BLUE EAGLE":"/assets/companies/examples/partsy.jpg",
  "CLEAVE":"/assets/companies/examples/caleb-ai.jpg",
  "BELOVED":"/assets/companies/examples/thankworthy.jpg",
  "D2X":"/assets/companies/examples/tentmaker.jpg",
  "TENTMAKER":"/assets/companies/examples/tentmaker.jpg",
  "ACTS":"/assets/companies/examples/acts.jpg",
  "THANKWORTHY":"/assets/companies/examples/thankworthy.jpg",
  "RAZED":"/assets/companies/examples/greenwood-labs.jpg",
  "FLYY":"/assets/companies/examples/world-rebuilders.jpg",
  "BLACK EAGLE":"/assets/companies/examples/agree-legal.jpg",
  "ALPHA7":"/assets/companies/examples/alpha7.jpg"
};

export default function Studios({embedded=false}:{embedded?:boolean}){
 const openStudio=(studio:(typeof studios)[number])=>window.dispatchEvent(new CustomEvent("higher:drawer-open",{detail:{type:"studio",studio}}));
 return <section id="studios" className={embedded?"studios studiosEmbedded":"studios section"}>
   <div className="studioGrid studioRevealGrid">
    {studios.map(s=><article className="studio studioReveal" key={s.slug} tabIndex={0}>
      <Image className="studioPhoto" src={studioImages[s.name]} alt="" fill sizes="(max-width: 1100px) 22vw, 15vw"/>
      <div className="studioPhotoShade"/>
      <div className="studioFace">
        <div className="studioMark"><StudioLogo studio={s.name} /></div>
      </div>
      <div className="studioRevealCopy"><strong>{s.name}</strong><p>{s.detail}</p><button type="button" className="studioExplore" onClick={()=>openStudio(s)}>EXPLORE THE STUDIO</button></div>
    </article>)}
   </div>
 </section>
}