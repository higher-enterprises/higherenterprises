"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { enterprises } from "@/data/enterprises";

const ENTER_MS = 1250;
const HOLD_MS = 5600;
const EXIT_MS = 1450;

type Phase = "entering" | "holding" | "transitioning";

export default function CompaniesVerticalRail() {
  const [active, setActive] = useState(0);
  const [next, setNext] = useState<number | null>(null);
  const [phase, setPhase] = useState<Phase>("entering");
  const [paused, setPaused] = useState(false);
  const timerRef = useRef<number | null>(null);
  const wheelLock = useRef(false);

  const clearTimer = useCallback(() => {
    if (timerRef.current !== null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const indexFrom = useCallback(
    (from: number, direction: number) =>
      (from + direction + enterprises.length) % enterprises.length,
    []
  );

  const beginTransition = useCallback(
    (direction = 1) => {
      if (phase === "transitioning" || !enterprises.length) return;
      clearTimer();
      setNext(indexFrom(active, direction));
      setPhase("transitioning");
    },
    [active, phase, clearTimer, indexFrom]
  );

  useEffect(() => {
    clearTimer();
    if (paused) return;

    if (phase === "entering") {
      timerRef.current = window.setTimeout(() => {
        setPhase("holding");
      }, ENTER_MS);
    } else if (phase === "holding") {
      timerRef.current = window.setTimeout(() => {
        setNext(indexFrom(active, 1));
        setPhase("transitioning");
      }, HOLD_MS);
    } else if (phase === "transitioning" && next !== null) {
      timerRef.current = window.setTimeout(() => {
        setActive(next);
        setNext(null);
        setPhase("holding");
      }, EXIT_MS);
    }

    return clearTimer;
  }, [active, next, phase, paused, clearTimer, indexFrom]);

  useEffect(() => {
    const onWheel = (event: WheelEvent) => {
      if (Math.abs(event.deltaY) < 30 || wheelLock.current) return;
      event.preventDefault();
      wheelLock.current = true;
      beginTransition(event.deltaY > 0 ? 1 : -1);
      window.setTimeout(() => {
        wheelLock.current = false;
      }, EXIT_MS + 180);
    };

    window.addEventListener("wheel", onWheel, { passive: false });
    return () => window.removeEventListener("wheel", onWheel);
  }, [beginTransition]);

  useEffect(() => clearTimer, [clearTimer]);

  if (!enterprises.length) return null;

  const renderSlide = (
    index: number,
    state: "entering" | "holding" | "exiting",
    role: "active" | "incoming"
  ) => {
    const item = enterprises[index];

    return (
      <article
        key={`${role}-${index}`}
        className={`enterpriseSlide ${state} ${role}`}
      >
        <div className="enterpriseCopy">
          <div className="enterpriseEyebrow">{item.eyebrow}</div>
          {item.logo && (
            <img className="enterpriseLogo" src={item.logo} alt={`${item.name} logo`} />
          )}
          <h1>{item.name}</h1>
          <p>{item.description}</p>
          {item.href ? (
            <a className="enterpriseExplore" href={item.href}>
              Visit Company <span aria-hidden="true">→</span>
            </a>
          ) : (
            <button type="button" className="enterpriseExplore">
              Explore Company <span aria-hidden="true">→</span>
            </button>
          )}
        </div>

        <div className="enterpriseVisualWrap">
          {item.hero && (
            <img className="enterpriseHeroVisual" src={item.hero} alt="" />
          )}
        </div>
      </article>
    );
  };

  const activeState =
    phase === "entering" ? "entering" :
    phase === "transitioning" ? "exiting" :
    "holding";

  return (
    <section
      className="enterpriseStage"
      aria-label="HIGHER companies"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="enterpriseBackdrop" aria-hidden="true">companies</div>

      <div className="enterpriseSlides">
        {renderSlide(active, activeState, "active")}
        {phase === "transitioning" && next !== null
          ? renderSlide(next, "entering", "incoming")
          : null}
      </div>

      <div className="enterprisePosition" aria-hidden="true">
        <span>{String(active + 1).padStart(2, "0")}</span>
        <i />
        <span>{String(enterprises.length).padStart(2, "0")}</span>
      </div>
    </section>
  );
}
