"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { companies } from "@/data/companies";
import VentureDrawnWorld from "@/components/VentureDrawnWorld";
import { ventureWorlds } from "@/data/ventureWorlds";

const featured = companies.filter((c) => c.featured && c.hero);

const ENTER_MS = 1250;
const HOLD_MS = 9000;
const FADE_MS = 1900;
const WANNA_GO_MS = 1150;

type Phase = "preenter" | "entering" | "holding" | "fading" | "gap";

export default function Hero() {
  const [active, setActive] = useState(0);
  const [phase, setPhase] = useState<Phase>("preenter");
  const [paused, setPaused] = useState(false);
  const timers = useRef<number[]>([]);

  const clearTimers = useCallback(() => {
    timers.current.forEach(window.clearTimeout);
    timers.current = [];
  }, []);

  const runCycle = useCallback(() => {
    clearTimers();

    // Paint the next venture below the viewport first so it
    // rises naturally from behind the existing cloud horizon.
    setPhase("preenter");

    timers.current.push(
      window.setTimeout(() => setPhase("entering"), 80)
    );

    timers.current.push(
      window.setTimeout(
        () => setPhase("holding"),
        80 + ENTER_MS
      )
    );

    timers.current.push(
      window.setTimeout(
        () => setPhase("fading"),
        80 + ENTER_MS + HOLD_MS
      )
    );

    timers.current.push(
      window.setTimeout(
        () => setPhase("gap"),
        80 + ENTER_MS + HOLD_MS + FADE_MS
      )
    );

    timers.current.push(
      window.setTimeout(() => {
        setActive((v) => (v + 1) % featured.length);
      }, 80 + ENTER_MS + HOLD_MS + FADE_MS + WANNA_GO_MS)
    );
  }, [clearTimers]);

  useEffect(() => {
    if (paused) {
      clearTimers();
      return;
    }

    runCycle();

    return clearTimers;
  }, [active, paused, runCycle, clearTimers]);

  useEffect(() => {
    let resume: number | undefined;

    const onWheel = (e: WheelEvent) => {
      if (Math.abs(e.deltaY) < 28) return;

      e.preventDefault();
      clearTimers();
      setPaused(true);
      setPhase("fading");

      window.setTimeout(() => {
        setPhase("gap");

        window.setTimeout(() => {
          setActive(
            (v) =>
              (v + (e.deltaY > 0 ? 1 : -1) + featured.length) %
              featured.length
          );

          setPhase("preenter");
          setPaused(false);
        }, WANNA_GO_MS);
      }, FADE_MS);

      if (resume) {
        window.clearTimeout(resume);
      }
    };

    window.addEventListener("wheel", onWheel, {
      passive: false,
    });

    return () => {
      window.removeEventListener("wheel", onWheel);

      if (resume) {
        window.clearTimeout(resume);
      }
    };
  }, [clearTimers]);

  if (!featured.length) return null;

  const item = featured[active];

  return (
    <section
      className="ventureStage"
      aria-label="Featured ventures"
    >
      <div className="wannaGo" aria-hidden="true">
        wanna go?
      </div>

      <div className="ventureSlides">
        <article
          className={`ventureSlide ${phase} ${
            ventureWorlds[item.name] ? "ventureSlideWithWorld" : ""
          }`}
          key={item.name}
        >
          {ventureWorlds[item.name] && (
            <div className="ventureWorld" aria-hidden="true">
              <div className="ventureWorldDrawing">
                <VentureDrawnWorld name={item.name} />
              </div>
              <div className="ventureWorldReadability" />
            </div>
          )}

          <div className="ventureSlideCopy">
            {item.logo ? (
              <img
                className="ventureHeroLogo"
                src={item.logo}
                alt={`${item.name} logo`}
              />
            ) : (
              <div className="ventureHeroNameMark">
                {item.name}
              </div>
            )}

            <h1>{item.name}</h1>

            <p>{item.description}</p>

            <button
              type="button"
              className="ventureExplore"
              onClick={() =>
                window.dispatchEvent(
                  new CustomEvent("higher:drawer-open", {
                    detail: {
                      company: item,
                    },
                  })
                )
              }
            >
              Explore Venture <span>→</span>
            </button>
          </div>

          <div className="ventureVisualWrap">
            <img
              className="ventureHeroVisual"
              src={item.hero}
              alt={item.name}
            />
          </div>
        </article>
      </div>
    </section>
  );
}