import Link from "next/link";

export default function Header() {
  return (
    <header className="header">
      <Link className="brand" href="/"><b>HIGHER</b></Link>
      <nav aria-label="Primary navigation">
        <Link href="/ventures">Ventures</Link>
        <Link href="/studios">Studios</Link>
        <Link href="/companies">Companies</Link>
        {/* <Link href="/guidance">Guidance</Link> */}
        <Link href="/academy">Academy</Link>
        <Link href="/perspective">Perspective</Link>
        {/* <Link href="/about">About</Link> */}
      </nav>
      <Link className="headerCta" href="/contact">I Wanna Go <span aria-hidden="true"></span></Link>
    </header>
  );
}
