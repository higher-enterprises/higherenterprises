"use client";
import Image from "next/image";
const logoMap:Record<string,string>={
 "SIBZ":"/assets/studios/official/sibz-lockup.png",
 "BLUE EAGLE":"/assets/studios/official/blue-eagle-lockup.png",
 "CLEAVE":"/assets/studios/official/realsite-lockup.png",
 "BELOVED":"/assets/studios/official/beloved-lockup.png",
 "D2X":"/assets/studios/official/d2x-lockup.png",
 "TENTMAKER":"/assets/studios/official/tentmaker-lockup.png",
 "ACTS":"/assets/studios/official/acts-lockup.png",
 "THANKWORTHY":"/assets/studios/official/thankworthy-lockup.png",
 "RAZED":"/assets/studios/official/razed-lockup.png",
 "FLYY":"/assets/studios/official/flyy-lockup.png",
 "BLACK EAGLE":"/assets/studios/official/black-eagle-lockup.png",
 "ALPHA7":"/assets/studios/official/alpha7-lockup.png"
};
export default function StudioLogo({studio,tiny=false}:{studio:string;tiny?:boolean}){
 const key=studio.replace(/\.VENTURES$/i,"").trim().toUpperCase();
 const src=logoMap[key]; if(!src)return null;
 return <Image className={tiny?"officialStudioLogo tiny":"officialStudioLogo"} src={src} alt={`${key} Ventures`} width={tiny?28:320} height={tiny?28:190}/>;
}