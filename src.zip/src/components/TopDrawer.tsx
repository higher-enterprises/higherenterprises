"use client";

import Image from "next/image";
import { X, ExternalLink, MapPin, Users, CalendarDays, Activity, Building2, Target, Handshake, Zap, Factory, Tags } from "lucide-react";
import { useEffect, useState } from "react";
import type { Company } from "@/data/companies";
import type { Studio } from "@/data/studios";
import StudioLogo from "@/components/StudioLogo";

type DrawerCompany = Company & {
  url?: string;
  logo?: string;
  location?: string;
  founded?: string;
  partners?: string[];
  seeking?: string[];
};

const demoNews = [
  { type:"Feature", date:"Sep 12, 2026", title:"Turning Play Into Purpose", copy:"Interactive experiences connect participation to measurable real-world rebuilding.", image:"/assets/companies/examples/world-rebuilders.jpg" },
  { type:"Update", date:"Aug 28, 2026", title:"First Community Build Partnership", copy:"A new on-the-ground initiative moves the concept from play toward place.", image:"/assets/companies/examples/greenwood-labs.jpg" },
  { type:"Story", date:"Jul 30, 2026", title:"From Blight to Opportunity", copy:"A closer look at communities and the people behind the mission.", image:"/assets/companies/examples/thankworthy.jpg" },
];

const studioShort=(studio:string)=>studio.replace(/\.VENTURES$/i,"").replace(/ VENTURES$/i,"").replace(/^HIGHER\s+/i,"");

export default function TopDrawer() {
  const [company,setCompany]=useState<DrawerCompany|null>(null);
  const [open,setOpen]=useState(false);
  const [investOpen,setInvestOpen]=useState(false);
  const [article,setArticle]=useState<any>(null);
  const [studio,setStudio]=useState<Studio|null>(null);

  useEffect(()=>{
    const onOpen=(event:Event)=>{
      const detail=(event as CustomEvent).detail||{};
      if(detail.type==="article" && detail.article){ setArticle(detail.article); setCompany(null); setStudio(null); setOpen(true); return; }
      if(detail.type==="studio" && detail.studio){ setArticle(null); setCompany(null); setStudio(detail.studio); setOpen(true); return; }
      if(detail.company){ setArticle(null); setStudio(null); setCompany(detail.company); setOpen(true); return; }
      // Preserve compatibility with any older generic drawer calls.
      setCompany({
        name:detail.title||"Details", studio:"HIGHER.VENTURES", industry:"", stage:"Ideation",
        impacts:[], description:detail.html?.replace(/<[^>]+>/g," ")||"", image:"/assets/companies/examples/alpha7.jpg", tags:[]
      } as DrawerCompany);
      setOpen(true);
    };
    const onClose=()=>setOpen(false);
    window.addEventListener("higher:drawer-open",onOpen);
    window.addEventListener("higher:drawer-close",onClose);
    return()=>{window.removeEventListener("higher:drawer-open",onOpen);window.removeEventListener("higher:drawer-close",onClose)};
  },[]);

  const close=()=>{
    setInvestOpen(false);
    window.dispatchEvent(new Event("higher:drawer-close"));
  };
  if(studio) return <aside id="top-drawer" className="topDrawer studioJoinDrawer" data-open={open?"true":"false"}><div className="studioJoinInner"><button className="drawerClose" aria-label="Close studio details" onClick={close}><X size={22}/></button><div className="studioJoinBrand"><StudioLogo studio={studio.name}/></div><h2>{studio.name}</h2><p className="studioJoinFocus">{studio.focus}</p><p className="studioJoinDetail">{studio.detail}</p><div className="studioJoinRule"/><h3>Request to Join the Incubator</h3><p className="studioJoinIntro">Tell us about you, what you are building, and why this studio is the right environment for the venture.</p><form className="studioJoinForm" onSubmit={(e)=>e.preventDefault()}><div className="studioJoinFields"><label>Name<input name="name" required/></label><label>Email<input name="email" type="email" required/></label><label>Organization / Venture<input name="venture"/></label><label>Role<select name="role" defaultValue="founder"><option value="founder">Founder</option><option value="cofounder">Co-Founder</option><option value="builder">Builder</option><option value="other">Other</option></select></label></div><label>What are you building?<textarea name="message" rows={3}/></label><button type="submit">Request to Join <span>→</span></button></form></div></aside>;
  if(article) return <aside id="top-drawer" className="topDrawer articleDrawer" data-open={open?"true":"false"}>
    <div className="articleDrawerInner">
      <button className="drawerClose" aria-label="Close article" onClick={close}><X size={22}/></button>
      <p className="kicker">{article.type} · {article.studio}</p>
      <h2>{article.title}</h2>
      <p className="articleDate">{article.date}</p>
      <div className="articleBody"><p>{article.copy}</p><p>This article space is reserved exclusively for the story, its media, supporting details and related editorial content. Venture or company profile information is intentionally kept out of the article drawer.</p></div>
    </div>
  </aside>;
  if(!company) return <aside id="top-drawer" className="topDrawer" data-open="false"/>;

  const isWorld=company.name==="World Rebuilders";
  const url=company.url || (isWorld ? "worldrebuilders.com" : "Company website");
  const location="Lincoln, CA";
  const founded=company.founded || "2026";
  const partners=company.partners || [];

  return (
    <aside id="top-drawer" className="topDrawer companyProfileDrawer" data-open={open?"true":"false"} aria-live="polite">
      <div className="companyDrawerInner">
        <button className="drawerClose" aria-label="Close details" onClick={close}><X size={22}/></button>

        <div className="companyDrawerBackdrop" aria-hidden="true">
          <Image src={company.image} alt="" fill sizes="100vw"/>
        </div>

        <div className="companyProfileGrid">
          <section className="companyProfileMain">
            <div className="companyDrawerPhoto"><Image src={company.image} alt={`${company.name}`} fill sizes="28vw"/></div>
          </section>
          <section className="companyProfileCenter">
            <div className="companyDrawerIdentity">
              {company.logo ? <div className="companyDrawerLogo"><Image src={company.logo} alt={`${company.name} logo`} fill sizes="220px"/></div> : <h2>{company.name}</h2>}
              {company.logo && <h2>{company.name}</h2>}
              <div className="companyProfileDescription">
                <p>{company.description}</p>
                <p>We are developing this venture around a focused market need, a clear customer experience, and a model designed to grow into a durable operating company.</p>
              </div>
              <div className="companyProfileActions"><button className="investWithCompany" onClick={()=>setInvestOpen(true)}>Invest With This Company <span>→</span></button></div>
            </div>
          </section>
          <aside className="companyProfileRight">
            <div className="companyAlignedDetails"><div className="companyFactGrid">
              <div className="companyFact"><ExternalLink/><span>URL</span><b>{company.url}</b></div>
              <div className="companyFact"><MapPin/><span>Location</span><b>{company.location}</b></div>
              <div className="companyFact"><CalendarDays/><span>Founded</span><b>{company.founded}</b></div>
              <div className="companyFact"><Building2/><span>Venture Studio</span><b>{studioShort(company.studio)}</b></div>
              <div className="companyFact"><Activity/><span>Stage</span><b className="factStage" style={{background:company.stageColor}}>{company.stage}</b></div>
              <div className="companyFact"><Factory/><span>Industry</span><b>{company.industry}</b></div>
              <div className="companyFact"><Target/><span>Impact Areas</span><b>{company.impact}</b></div>
              <div className="companyFact"><Handshake/><span>Partners</span><b>{company.partners}</b></div>
              <div className="companyFact companyFactClassifications">
                <Tags/>
                <span>Classifications</span>
                <div className="classificationFactValues">
                  {(company.tags || []).map((tag:string)=><b key={tag}>{tag}</b>)}
                </div>
              </div>
            </div></div>
            <section className="companyNews companyDrawerStatus"><h3>NEWS</h3><p>No news at the moment.</p></section>
            <section className="companyJobs companyDrawerStatus"><h3>JOBS</h3><p>No open positions posted.</p></section>
          </aside>
        </div>

        <div className={`investmentContactDrawer ${investOpen ? "isOpen" : ""}`} aria-hidden={!investOpen}>
          <button className="investmentContactClose" aria-label="Close investment form" onClick={()=>setInvestOpen(false)}><X size={20}/></button>
          <p className="kicker">INVEST WITH THIS COMPANY</p>
          <h3>{company.name}</h3>
          <p className="investmentContactIntro">Tell us about your interest in this company.</p>
          <form className="investmentContactForm" onSubmit={(e)=>e.preventDefault()}>
            <label>Name<input name="name" type="text" required /></label>
            <label>Email<input name="email" type="email" required /></label>
            <label>Phone Number<input name="phone" type="tel" required /></label>
            <label>Organization<input name="organization" type="text" /></label>
            <label>Investment Range
              <select name="range" defaultValue="">
                <option value="" disabled>Select a range</option>
                <option>$10K–$25K</option><option>$25K–$50K</option><option>$50K–$100K</option>
                <option>$100K–$250K</option><option>$250K+</option>
              </select>
            </label>
            <label>Message<textarea name="message" rows={3} placeholder={`I'm interested in learning more about ${company.name}...`} /></label>
            <button type="submit">Send Investment Inquiry <span>→</span></button>
          </form>
        </div>
      </div>
    </aside>
  );
}
