"use client";

import { ventureWorlds } from "@/data/ventureWorlds";

export default function VentureDrawnWorld({ name }: { name: string }) {
  const world = ventureWorlds[name];
  if (!world) return null;

  const count = Math.max(1, world.paths.length - 1);

  return (
    <svg
      className="ventureDrawnWorld"
      viewBox={`0 0 ${world.width} ${world.height}`}
      preserveAspectRatio="xMidYMid slice"
      role="presentation"
      aria-hidden="true"
    >
      {world.paths.map((d, i) => (
        <path
          key={`${name}-${i}`}
          className="ventureMappedStroke"
          d={d}
          pathLength="1"
          style={{
            // Hero owner completes entrance at ~1330ms.
            // No background drawing begins until 1750ms.
            // ventureWorlds paths are sorted TOP -> BOTTOM.
            ["--trace-delay" as string]:
              `${1750 + Math.round((i / count) * 4300)}ms`,
            ["--trace-duration" as string]:
              `${500 + (i % 8) * 55}ms`,
          }}
        />
      ))}
    </svg>
  );
}
