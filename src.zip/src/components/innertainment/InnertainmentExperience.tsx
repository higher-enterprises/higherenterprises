"use client";
import {useState} from "react";
import {ChevronLeft,ChevronRight,Pause,Play,Volume2,X} from "lucide-react";
import {media} from "@/lib/innertainment/content";
export default function InnertainmentExperience(){
 const [active,setActive]=useState(3),[preview,setPreview]=useState<number|null>(null),[playing,setPlaying]=useState(false);
 const move=(d:number)=>setActive(v=>(v+d+media.length)%media.length); const item=preview===null?null:media[preview];
 return <main className="innerPage">
  <aside className="innerIntro"><div><b>HIGHER</b><h1>INNERTAINMENT</h1><p>Stories worth letting in.</p><i/><small>WATCH · LISTEN · EXPERIENCE</small></div></aside>
  <section className="innerChannel">
   <button className="innerArrow left" onClick={()=>move(-1)}><ChevronLeft/></button>
   <div className="innerCards">{media.map((m,i)=><button key={m.slug} className={`innerCard ${i===active?"isActive":""}`}
    style={{"--d":i-active} as React.CSSProperties} onMouseEnter={()=>setActive(i)} onFocus={()=>setActive(i)} onClick={()=>setPreview(i)}>
    <img src={m.image} alt=""/><span className="innerShade"/><em>{m.source}</em><strong>{m.title}</strong><small>{m.type}</small>
    {i===active&&<i className="innerPlay"><Play size={16} fill="currentColor"/></i>}</button>)}</div>
   <button className="innerArrow right" onClick={()=>move(1)}><ChevronRight/></button>
   <nav className="innerNav"><button className="active">Originals</button><button>Conversations</button><button>Documentaries</button><button>Series</button><button>Podcasts</button><button>Live</button></nav>
  </section>
  {item&&<div className="innerBackdrop" onClick={()=>setPreview(null)}><section className="innerPreview" onClick={e=>e.stopPropagation()}>
   <img src={item.wide} alt="" className="innerPreviewArt"/><span className="innerPreviewShade"/>
   <button className="innerClose" onClick={()=>setPreview(null)}><X/></button>
   <div className="innerCopy"><em>{item.source}</em><h2>{item.title}</h2><b>{item.type}</b><p>{item.description}</p>
    <button className="innerPrimary" onClick={()=>setPlaying(v=>!v)}>{playing?<Pause size={16}/>:<Play size={16} fill="currentColor"/>}{playing?"Pause":"Play Preview"}</button></div>
   <div className="innerPlayer"><span>00:00</span><div className="innerTrack"><i className={playing?"playing":""}/></div>
    <button onClick={()=>setPlaying(v=>!v)}>{playing?<Pause/>:<Play fill="currentColor"/>}</button><Volume2/><span>01:12</span></div>
  </section></div>}
 </main>
}