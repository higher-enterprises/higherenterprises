"use client";

import { ReactNode } from "react";
import Header from "@/components/Header";
import CloudHorizon from "@/components/CloudHorizon";
import TopDrawer from "@/components/TopDrawer";

export default function SiteShell({ children }: { children: ReactNode }) {
  return (
    <div className="siteShell">
      <Header />
      <main className="siteViewport">{children}</main>
      <CloudHorizon />
      <TopDrawer />
    </div>
  );
}
